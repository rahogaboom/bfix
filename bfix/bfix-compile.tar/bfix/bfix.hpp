#ifndef BFIX_HPP
#define BFIX_HPP

/*
 * File: bfix.hpp
 *
 * Description:
 *     header file for bfix.cpp
 *
 */

    int
bfi
    (
        unsigned char *cptr,
        unsigned long bit_offset,
        unsigned long bit_len,
        long value,
        unsigned int endian
    );

    long
bfx
    (
        const unsigned char *cptr,
        unsigned long bit_offset,
        unsigned long bit_len,
        unsigned int endian
    );

#endif
